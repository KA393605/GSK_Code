<template>
    <div>
        <router-view></router-view>
    </div>
</template>

<script>
//import Users from '../components/Users.vue'
export default {
    name:'Home',
    components:{
      //  Users
    },
    data(){
        return{

        }
    }
}
</script>