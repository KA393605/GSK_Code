<template>
    <div>
        <div v-if="message">
            <h2>Successfully Logged In</h2><br>
            From:<input type="date" placeholder="From Date" v-model="from_date" @change="checkfromDate"/>
            To:<input type="date" placeholder="To Date" v-model="to_date" @change="checktoDate"/><br>
            <p>* Choose a proper interval to Audit</p>

            <button :disabled="invalid" @click="submit__Audit">Audit</button>
        </div>
        <div v-else>
            <h2>Login Failed due to : {{error_message}}</h2>
        </div>
    </div>
</template>

<script>
import axios from "axios";
import { server } from "../helper";
export default {
    name:'Home',
    data(){
        return{
            message:false,
            from_date:'',
            to_date:'',
            invalid:true,
            error_message:''
        }
    },
    created(){
        if(this.$route.params.message==="Success"){
            this.message=true
            console.log(this.message)
        }
        else{
            this.error_message=this.$route.params.message;
        }
    },
    methods:{
        checkfromDate(){
            console.log(this.from_date+"T00:00:00Z")
        },
        checktoDate(){
            console.log(this.to_date+"T00:00:00Z");
            this.invalid=new Date(this.from_date) > new Date(this.to_date);
            console.log(this.invalid);
        },
        submit__Audit(){
            let data={
                from_date:this.from_date+"T00:00:00Z",
                to_date:this.to_date+"T00:00:00Z"
            };
            console.log(data.to_date,data.from_date)
             axios
            .post(`${server.baseURL}/customer`, data)
            .then((data)=>{
                console.log(data)
            })
            .catch((error)=>{
                    console.log(error)
            })
        }
    }
}
</script>