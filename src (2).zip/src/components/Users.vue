<template>
  <div>
    <div class="col-md-12 form-wrapper">
      <h2>User</h2>
      <form id="create-post-form" v-on:submit.prevent>
        <div class="form-group col-md-12">
          <label for="title">User Name</label>
          <input
            type="text"
            id="name"
            v-model="name"
            name="title"
            class="form-control"
            placeholder="Enter Name"
          />
        </div>
        <div class="form-group col-md-12">
          <label for="title">Password</label>
          <input
            type="password"
            id="password"
            v-model="password"
            name="title"
            class="form-control"
            placeholder="Enter Password"
          />
        </div>

        <div class="form-group col-md-4 pull-right">
          <button class="btn btn-success" @click="login">Authenticate</button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import { server } from "../helper";
import router from "../router";
export default {
  data() {
    return {
      name: "",
      password: "",
      loginData: ""
    };
  },
  methods: {
    login() {
      this.loginData = {
        username: this.name,
        password: this.password
      };
      this.__submitToServer();
    },
    __submitToServer() {
      console.log(this.loginData.person_name, this.loginData.password); //To check the value passed from form
      axios
        .post(`${server.baseURL}/customer/login`, this.loginData)
        .then((data) => {
           if(data.status==="Success"){
              router.push({name:'auth',params: { 'message': data.status }});
           }
           else{
              router.push({name:'auth',params: { 'message': "Invalid User" }});
           }
        })
        .catch(error => {
          console.log("Connection failed due to: " + error);
              router.push({name:'auth',params: { 'message':error }});
        });
    }
  }
};
</script>

<style>
h3 {
  margin-bottom: 5%;
}
</style>