import Vue from 'vue'
import Router from 'vue-router'
//import HomeComponent from '@/views/Home';
import loginapp from '@/components/loginapp.vue';
import Users from '@/components/Users.vue'
import Home from '@/components/Home.vue'
Vue.use(Router)
export default new Router({
  mode: 'history',
  routes: [
    { path: '/', redirect: { name: 'form' } ,component:loginapp,
      children:[
        { path: '/create', name: 'form', component: Users },
        { path:'/auth',name:'auth',component:Home}
      ] },
   
    //{ path: '/create', name: 'create', component: UserComponent },
    //{ path: '/edit/:id', name: 'Edit', component: EditComponent },
  ]
});