export const server = {
    baseURL: 'http://localhost:4000'
}