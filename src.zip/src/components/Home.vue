<template>
    <div >
        <div v-if="message">
             <img :src="image" />
            <h3>Successfully Logged In</h3><hr><br>
            <form class="form-inline">
             <label for="email" class="mr-sm-2">From Date:</label><input type="date" class="form-control mb-2 mr-sm-2" placeholder="From Date" v-model="from_date" />
             <label for="email" class="mr-sm-2 indate">To Date:</label><input type="date" class="form-control mb-2 mr-sm-2" placeholder="To Date" v-model="to_date" @change="checktoDate"/>
            </form>
             <p>* Choose a proper interval to Audit</p><br>
            <label for="email" class="mr-sm-2">Functional Account</label>
            <input type="text" placeholder="Enter MudId" class="form-control mb-2 mr-sm-2 inputtxt" v-model="text"/>
           
            <button :disabled="invalid" @click="submit__Audit" class="btn btn-primary">AUDIT</button>
        </div>
        <div v-else>
            <h2>Login Failed due to : {{error_message}}</h2>
        </div>
        <div v-if="display">
            <hr>
			<h4>{{result}}</h4>
        </div>
    </div>
</template>

<script>
import image from "../assets/logo.png"
import axios from "axios";
import { server } from "../helper";
export default {
    name:'Home',
    data(){
        return{
            image: image,
            message:false,
            from_date:'',
            to_date:'',
            invalid:true,
            display:false,
            text:'',
            error_message:'',
			result:''
        }
    },
    created(){
        if(this.$route.params.message==="SUCCESS"){
            this.message=true
        }
        else{
            this.error_message=this.$route.params.message;
        }
    },
    methods:{
        checktoDate(){
            this.invalid=new Date(this.from_date) > new Date(this.to_date);
        },
        submit__Audit(){
            let data={
                fromDate:this.from_date+"T00:00:00Z",
                toDate:this.to_date+"T00:00:00Z",
                Functional_account:this.text
            };
             axios
            .post(`${server.baseURL}/customer`, data)
            .then((data)=>{
				this.result=data.data;
				this.display=true;
            })
            .catch((error)=>{
                   this.result=error
            })
        }
    }
}
</script>

<style scoped>
form{
    margin-left: 30%;
}

.indate{
    margin-left: 20px;
}

.inputtxt{
    margin-left: 40%;
    width: 20%;
}
img{

  height: 100px;
  width: 100px;
}
</style>